<div class="modal fade" id="customerModal" tabindex="-1" role="dialog" aria-labelledby="customerModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #F98917;">
                <h5 class="modal-title" id="customerModalLabel">Add Suppliers</h5>
            </div>
            <div class="modal-body">

                {!! Form::open(['route' => 'suppliers.store', 'enctype' => 'multipart/form-data']) !!}
                @csrf
                <div class="form-group mb-3">
                    {!! Form::label('supplier_name', 'Supplier Name') !!}
                    {!! Form::text('supplier_name', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('supplier_type', 'Supplier Type') !!}
                    {!! Form::text('supplier_type', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('company_name', 'Company Name') !!}
                    {!! Form::text('company_name', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('contact_number', 'Contact Number') !!}
                    {!! Form::text('contact_number', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('pan_card_number', 'Pan Card Number') !!}
                    {!! Form::text('pan_card_number', null, ['class' => 'form-control']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('pan_card', 'pan_card') !!}
                    {!! Form::file('pan_card', ['class' => 'form-control ']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('business_card[]', 'Business Card Images') !!}
                    {!! Form::file('business_card[]', ['class' => 'form-control', 'multiple' => true, 'accept' => 'image/jpeg,image/png,application/pdf']) !!}
                </div>

                <div class="form-group mb-3">
                    {!! Form::label('memo', 'memo') !!}
                    {!! Form::file('memo', ['class' => 'form-control ']) !!}
                </div>

                <div class="form-group mt-3">
                    <label for="remarks">Remarks:</label>
                    <textarea class="form-control" id="remarks" name="remarks" rows="3"></textarea>
                </div>

                <div class="form-group d-grid gap-3 mt-3">
                    {!! Form::submit('Create Supplier', ['class' => 'btn dash1']) !!}
                </div>
                {!! Form::close() !!}

            </div>
        </div>
    </div>
</div>