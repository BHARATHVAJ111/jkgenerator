@extends('layouts.sidebar')

@section('content')
<div class="main mb-4 mt-1">
    <div class="row align-items-center">
        <div class="col">
            <div class="d-flex">
                <div class="me-3">@include('suppliers.edit')</div>
                <div>@include('suppliers.delete')</div>
            </div>
        </div>
        <div class="col-auto">
            <button type="button" class="btn dash1">
                <a href="{{ route('suppliers.index') }}" class="text-decoration-none text-dark">Back To Supplier</a>
            </button>
        </div>
        <div class="col-lg-12 mt-5" style="background-color:#D9D9D9">
            <ul class="list-unstyled">
                <li class="row">
                    <strong class="col-sm-3">Name:</strong>
                    <span class="col-sm-7">{{ $supplier->supplier_name }}</span>

                </li>
                <li class="row">
                    <strong class="col-sm-3">Type</strong>
                    <span class="col-sm-7">{{ $supplier->supplier_type }}</span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Company Name:</strong>
                    <span class="col-sm-7">{{ $supplier->company_name}}</span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Contact Number</strong>
                    <span class="col-sm-7">{{ $supplier->contact_number }}</span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Pancard Number</strong>
                    <span class="col-sm-7">{{ $supplier->pan_card_number }}</span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Pancard:</strong>
                    <span class="col-sm-7">
                        @if($supplier->pan_card)
                        <a href="{{ asset('storage/' . $supplier->pan_card) }}" target="_blank" class="text-decoration-underline">View PAN Card</a>
                        @else
                        No PAN Card uploaded
                        @endif
                    </span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Business Card:</strong>
                    <span class="col-sm-7">
                        @if($supplier->business_card)
                        @foreach(json_decode($supplier->business_card) as $index => $path)
                        <a href="{{asset('storage/' . $path) }}" target="_blank" class="text-decoration-underline">
                            Business Card {{ $index + 1 }}<br>
                            @endforeach
                        </a>
                        @else
                        No Business Card uploaded
                        @endif
                    </span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Memo:</strong>
                    <span class="col-sm-7">
                        @if($supplier->memo)
                        <a href="{{ asset('storage/' . $supplier->memo) }}" target="_blank" class="text-decoration-underline">View Memo</a>
                        @else
                        No Memo uploaded
                        @endif
                    </span>
                </li>
                <li class="row">
                    <strong class="col-sm-3">Remarks:</strong>
                    <span class="col-sm-7">{{ $supplier->remarks }}</span>
                </li>
            </ul>
        </div>
    </div>
</div>


@endsection