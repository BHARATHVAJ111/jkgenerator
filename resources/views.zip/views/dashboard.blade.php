@extends('layouts.sidebar')
@section('content')
<div class="main">
    <div class="row align-items-center">
    {{-- <div><h2 class="btn btn-primary text-white fw-bolder float-end mt-1">User Type: {{ auth()->user()->name }}</h2></div> --}}
        <div class="col">
            <div class="welcome-back">Hai Sales<span class="drop-truck"></span></div>
        </div>
        <div class="col-auto">
     
            <!-- <a href="#."><img src="images/dashboard/search.png" height="25" width="25"></a> -->
            <!-- Inside the 'content-wrapper' div -->
            @if(auth()->user()->role_id == 5 || auth()->user()->role_id == 6)
            <button type="button" class="btn btn-success dash1 mt-3" data-bs-toggle="modal" data-bs-target="#createIndentModal">Add</button>
            @endif
            

            <!-- Modal -->
            <div class="modal fade container-fluid" id="createIndentModal" tabindex="-1" aria-labelledby="createIndentModalLabel" aria-hidden="true">
                <div class="modal-dialog rounded" role="document">
                    <div class="modal-content">
                        <div class="modal-header fw-bolder text-white text-center" style="background:#F98917;">
                           ADD PARTS
                        </div>
                        <div class="modal-body">
                            @include('indent.create')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    @endsection