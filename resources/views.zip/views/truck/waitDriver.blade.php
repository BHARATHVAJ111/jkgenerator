@extends('truck.truck-page')
@section('content')
<div class="dropdown mt-3">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="true">
           Ongoing Trips
        </a>
        <a class="btn btn-secondary" href="#">
            Complete Trips
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="{{route('waitDriver')}}">Waiting For Driver</a></li>
            <li><a class="dropdown-item" href="#">Loading</a></li>
            <li><a class="dropdown-item" href="#">POD</a></li>
            <li><a class="dropdown-item" href="#">On The Road</a></li>
            <li><a class="dropdown-item" href="#">Unloading</a></li>
        </ul>
    </div>


@endsection
