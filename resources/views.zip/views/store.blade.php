@extends('layouts.sidebar')
@section('content')
    <div class="main">
        <div class="row align-items-center">
            {{-- <div><h2 class="btn btn-primary text-white fw-bolder float-end mt-1">User Type: {{ auth()->user()->name }}</h2></div> --}}
            <div class="col">
                <div class="welcome-back">Hai Sales<span class="drop-truck"></span></div>
            </div>

            <div class="col-auto">
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <!-- <a href="#."><img src="images/dashboard/search.png" height="25" width="25"></a> -->
                <!-- Inside the 'content-wrapper' div -->
                @if (auth()->user()->role_id == 5 || auth()->user()->role_id == 6)
                    <button type="button" class="btn btn-success dash1 mt-3" data-bs-toggle="modal"
                        data-bs-target="#createIndentModal">Add</button>
                @endif


                <!-- Modal -->
                <div class="modal fade container-fluid" id="createIndentModal" tabindex="-1"
                    aria-labelledby="createIndentModalLabel" aria-hidden="true">
                    <div class="modal-dialog rounded" role="document">
                        <div class="modal-content">
                            <div class="modal-header fw-bolder text-white text-center" style="background:#F98917;">
                                ADD PARTS
                            </div>
                            <div class="modal-body">
                                @include('indent.create')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="">
                <ul class="d-flex">
                    <p class="nav-item">
                        <a href=""
                            class="nav-link align-middle px-0 {{ request()->route()->getName() === 'indents.indent' ? 'active' : '' }}">
                            <span class="ms-1 d-none d-sm-inline">
                                <span class="ms-1">Assets</i></span>
                            </span>
                        </a>
                    </p>
                    <p class="nav-item">
                        <a href="{{ route('store.index') }}"
                            class="nav-link align-middle px-0 {{ request()->route()->getName() === 'store.index' ? 'active' : '' }}">
                            <span class="ms-1 d-none d-sm-inline">
                                <span class="ms-1">Parts</i></span>
                            </span>
                        </a>
                    </p>
                </ul>
            </div>
        </div>

        <table class="">
            <thead>
                <tr>
                    <th scope="col">Asset code</th>
                    <th scope="col">Material_name</th>
                    <th scope="col">Quantity</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($assets as $values)
                    <tr class="bg-light shadow rounded-circle pb-5">
                        <td>{{ $values->jrnum }}</td>
                        <td>{{ $values->material_name }}</td>
                        <td>{{ $values->number_of_quantity }}</td>
                        <td class="d-flex justify-content-around">

                            <a href="">
                                <i class="fa-sharp fa-solid fa-eye" style="color:black;"></i>
                            </a>

                            <a href="">
                                <i class="fa-regular fa-pencil"></i>
                            </a>
                            <a href="{{route('parts.delete',['id'=>$values->id])}}">
                                <i class="fa-solid fa-trash-can" style="color: #f50025;"></i>
                            </a>

                           <a href="{{ route('assets.edit', ['id' => $values->id]) }}">
                            <button type="button" class="btn btn-success" >Add</button>
                           </a>
                           <a href="{{route('parts.asign',['id' => $values->id])}}">
                               <button type="button" class="btn btn-primary" id="">Assign</button>
                           </a>

                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
       
        
    @endsection
